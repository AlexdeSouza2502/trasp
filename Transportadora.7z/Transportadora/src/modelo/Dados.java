/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author 11171009801
 */
public class Dados {
    
     public static List<Destino> listaDestino = new ArrayList<>();
     public static List<Funcionario> listaFuncionario = new ArrayList<>();
     public static List<Loja_De_Destino> listaLoja_De_Destino = new ArrayList<>();
     public static List<Transportadora> listaTransportadora = new ArrayList<>();
}
